require 'test_helper'

class CustomMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
