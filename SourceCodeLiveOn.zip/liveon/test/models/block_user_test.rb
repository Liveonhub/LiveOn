require 'test_helper'

class BlockUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
