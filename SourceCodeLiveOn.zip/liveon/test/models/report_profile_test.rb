require 'test_helper'

class ReportProfileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
