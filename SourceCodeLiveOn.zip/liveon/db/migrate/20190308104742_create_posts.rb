class CreatePosts < ActiveRecord::Migration[5.2]
  def change
    create_table :posts do |t|
      t.string :body
      t.string :post_type
      t.integer :death_person_id
      t.datetime :death_person_date
      t.integer :user_id
      t.timestamps
    end
  end
end
