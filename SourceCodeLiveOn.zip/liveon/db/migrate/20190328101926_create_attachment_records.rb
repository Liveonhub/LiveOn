class CreateAttachmentRecords < ActiveRecord::Migration[5.2]
  def change
    create_table :attachment_records do |t|
      t.string :attachment_type
      t.integer :attachment_id
      t.integer :user_id
      t.timestamps
    end
  end
end
