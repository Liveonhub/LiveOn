class Users::OmniauthCallbacksController < Devise::OmniauthCallbacksController
  def facebook
    @user = User.from_facebook_omniauth(request.env["omniauth.auth"])
    auth_params_from_fb_twitter_instagram
  end

  def twitter
    @user = User.from_twitter_omniauth(request.env["omniauth.auth"])
    auth_params_from_fb_twitter_instagram
  end

  def instagram
    @user = User.from_instagram_omniauth(request.env["omniauth.auth"])
    auth_params_from_fb_twitter_instagram
  end
  
  def failure
    redirect_to new_user_registration_url
  end

  private 
  def auth_params_from_fb_twitter_instagram
    if @user.persisted?
      sign_in @user, event: :authentication
      redirect_to new_user_path
    else
      session["devise.github_data"] = request.env["omniauth.auth"]
      redirect_to new_user_registration_path
    end
  end
end
