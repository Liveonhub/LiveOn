class Users::RegistrationsController < Devise::RegistrationsController
  prepend_before_action :check_captcha, only: [:create]

  def new
    super
  end

  def create
    build_resource(registration_params)
    if resource.save
      if resource.active_for_authentication?
        set_flash_message :notice, :signed_up if is_navigational_format?
        sign_up(resource_name, resource)
        respond_with resource, :location => after_sign_up_path_for(resource)
      else
        set_flash_message :notice, :"signed_up_but_#{resource.inactive_message}" if is_navigational_format?
        respond_with resource, :location => after_sign_up_path_for(resource)
      end
    else
      respond_with resource
    end
  end

  def update
    self.resource = resource_class.to_adapter.get!(send(:"current_#{resource_name}").to_key)
    prev_unconfirmed_email = resource.unconfirmed_email if resource.respond_to?(:unconfirmed_email)

    resource_updated = update_resource(resource, registration_params)
    yield resource if block_given?
    if resource_updated
      flash[:success] = "Your password has been changed successfully"
      bypass_sign_in resource, scope: resource_name if sign_in_after_change_password?
      redirect_to edit_user_registration_path(resource)
    else
      clean_up_passwords resource
      set_minimum_password_length
      respond_with resource
    end
  end

  private
  def registration_params
    params.require(:user).permit(:email, :first_name, :last_name, :user_name, :mobile_number, :password, :password_confirmation, :current_password, :date_of_birth, :gender, :term_and_condition)
  end

  def check_captcha
    unless verify_recaptcha
      self.resource = resource_class.new registration_params
      resource.validate # Look for any other validation errors besides Recaptcha
      resource.errors[:base] <<  "Recaptcha is not verified. Please verify this"
      set_minimum_password_length
      respond_with resource
    end 
  end
end
