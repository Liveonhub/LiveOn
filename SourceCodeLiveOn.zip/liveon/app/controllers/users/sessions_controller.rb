class Users::SessionsController < Devise::SessionsController
  def new
    redirect_to new_user_registration_path
  end

  # POST /resource/sign_in
  def create
    resource = User.find_for_database_authentication(email: params[:user][:email])
    if (resource && resource.valid_password?(params[:user][:password])) && (verify_recaptcha || params["g-recaptcha-response"].present?)
      sign_in :user, resource
      flash[:success] = nil
      respond_to do |format|
        format.js {render inline: "location.reload();" }
      end
    elsif (resource.present?) && resource.valid_password?(params[:user][:password])
      @message = "Recaptcha is not verified. Please verify this"
    elsif verify_recaptcha || params["g-recaptcha-response"].present?
      @message = "Invalid Email or Password"
    else 
      @message = "both_error"
    end

  end
end
