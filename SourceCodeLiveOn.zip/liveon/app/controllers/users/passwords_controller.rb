class Users::PasswordsController < Devise::PasswordsController
  prepend_before_action :check_captcha, only: [:update]

  # def new
  #   super
  # end

  def create
    self.resource = resource_class.send_reset_password_instructions(resource_params)
    yield resource if block_given?
    if successfully_sent?(resource)
      flash[:success] = 'Reset password link has been sent to your email address.'
    else
      @message = 'Email not found.'
    end
  end

  # GET /resource/password/edit?reset_password_token=abcdef
  # def edit
  # end

  # PUT /resource/password
  def update
    super
  end

  protected
  
  def check_captcha
    unless verify_recaptcha
      self.resource = resource_class.new
      resource.errors[:base] <<  "Recaptcha is not verified. Please verify this"
      respond_with resource
    end 
  end


end
