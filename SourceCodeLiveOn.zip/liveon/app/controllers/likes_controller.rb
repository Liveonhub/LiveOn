class LikesController < ApplicationController
  before_action :set_parent
  
  def create
    @like = @parent.likes.create
    @like.user_id = current_user.id
    @like.save
  end

  def destroy
    @like = Like.find(params[:id])
    @like.destroy
  end

  private
  def set_parent
    @parent = if params[:comment_id].present?
      Comment.find(params[:comment_id])
    elsif params[:post_id].present?
      Post.find(params[:post_id])      
    else
      Comment.find(params[:reply_id])
    end
  end
end
