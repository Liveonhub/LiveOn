class NomineesController < ApplicationController

  def new
    @nominees = []
    2.times do |nominee|
      @nominees << if current_user.nominees[nominee].present?
        current_user.nominees[nominee]
      else
        Nominee.new
      end
    end
  end

  def create
    if params[:nominee_id].present?
      @nominee = Nominee.find_by_id(params[:nominee_id])
      @nominee.full_name = nominee_params[:full_name]
      @nominee.email = nominee_params[:email]
      @nominee.mobile_number = nominee_params[:mobile_number]
    else
      @nominee = current_user.nominees.new(nominee_params)
    end
    if @nominee.save
      flash[:success] = 'Nominee saved successfully'
      redirect_to new_nominee_path
    else
      respond_to do |format|
        format.js  {}
      end      
    end
  end

  private
  def nominee_params
    params.require(:nominee).permit(:email, :mobile_number, :full_name)
  end
end
