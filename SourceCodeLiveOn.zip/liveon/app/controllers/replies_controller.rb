class RepliesController < ApplicationController
  before_action :set_comment

  def create
    @reply = @comment.replies.create(reply_params)
    @reply.user_id = current_user.id
    @reply.post_id = @comment.post_id
    @reply.save
  end

  def destroy
    @reply = @comment.replies.find(params[:id])
    @reply.destroy
  end

  private
  def reply_params
    params.require(:comment).permit(:body, :user_id, :post_id, :parent_id)
  end  

  def set_comment
    @comment = Comment.find(params[:comment_id])
  end
end
