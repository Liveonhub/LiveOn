class ReportProfilesController < ApplicationController

  def update
    @block_user = current_user.block_users.create(block_user_id: params[:id])
    if @block_user.persisted?
      @success_message = "Profile blocked"
    else
      @error_message = "Profile not blocked"
    end
  end

  def unblock
    @block_user = BlockUser.find_by_user_id_and_block_user_id(params[:user_id], params[:report_profile_id])
    if @block_user.present? && @block_user.destroy
      @success_message = "Profile unblocked"
    else
      @error_message = "Profile not unblocked"
    end
  end

  def create
    params[:report_profile][:report_profile_id] = params[:user_id]
    @report_profile = current_user.report_profiles.create(report_profile_params)
    if @report_profile.persisted?
      @report_profile = @report_profile.report_profile
      @success_message = "Reported about profile"
    else
      @error_message = "Profile not reported"
    end
  end

  def destroy
    @report_profile =  ReportProfile.find_by_user_id_and_report_profile_id(params[:user_id], params[:id])
    if @report_profile.present? && @report_profile.destroy
      @report_profile = @report_profile.report_profile
      @success_message = "Reported request deleted"
    else
      @error_message = "Reported request not deleted"
    end
  end

  private
  def report_profile_params
    params.require(:report_profile).permit(:title, :user_id, :report_profile_id)
  end
end
