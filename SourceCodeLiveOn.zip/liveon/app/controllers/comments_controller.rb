class CommentsController < ApplicationController
  before_action :set_post_comment

  def show
  end

  def create
    @comment = @post.comments.create(comment_params)
    @comment.user_id = current_user.id
    if @comment.save
      respond_to do |format|
        format.html {}
        format.js  {}
      end
    end
  end

  def edit
  end

  def update
    if @comment.update_attributes(comment_params)
      respond_to do |format|
        format.html {}
        format.js
      end 
    end    
  end

  def destroy
    if @comment.destroy
      respond_to do |format|
        format.html {}
        format.js
      end
    end 
  end

  private
  def comment_params
    params.require(:comment).permit(:body, :user_id, :post_id)
  end

  def set_post_comment
    @post = Post.find(params[:post_id])
    @comment = @post.comments.find(params[:id]) if params[:action] != "create"
  end
end
