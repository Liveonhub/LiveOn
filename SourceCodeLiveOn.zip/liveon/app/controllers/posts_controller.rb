class PostsController < ApplicationController
  include UsersHelper
  before_action :find_post,  except: %i(index create user_posts death_friend_post)
  before_action :initialize_post_comment,  only: %i(index user_posts create)

  def index
    @posts =  Post.post_by_type(current_user)
    respond_to do |format|
      format.html {}
      format.js  {}
    end 
  end

  def new
    respond_to do |format|
      format.js  {}
    end 
  end

  def create
    params[:post][:death_person_id] = User.find_by_email(params[:post][:death_person_id].split(/[()]/)[1]).id.to_s if params[:post_category] == "2"
    @post = current_user.posts.create(post_params)
    if @post.persisted?
      respond_to do |format|
        format.js  {}
      end 
    else
      render 'new'
    end 
  end

  def edit
    respond_to do |format|
      format.js  {}
    end
  end


  def update
    if @post.update_attributes(post_params)
      respond_to do |format|
        format.js  {}
      end
    end
  end

  def destroy
    if @post.destroy
      respond_to do |format|
        format.js  {}
      end
    end
  end

  def user_posts
    @user = User.find(params[:user_id])
    @posts = @user.posts.post_by_type(current_user)
  end 

  def death_friend_post
    users = User.search_friends(params[:search], current_user.id)
    @users = []
    users.each do |user|
      @users << {
        id: user.id,
        value: "#{user.full_name} (#{user.email})",
        label: "#{user.email}",
        img: get_image_path(user, 'profile_photo', 'death_friend')
      }
    end
    # @users = params[:search].blank? ? [] : @users
    respond_to do |format|
      format.json { 
        render json: @users
      }
    end  
  end

  private
  def post_params
    params.require(:post).permit(:body, :post_type, :death_person_id, :death_person_date, images: [])
  end

  def find_post
    @post = current_user.posts.find(params[:id])
  end

  def initialize_post_comment
    @post = Post.new
    @comment = Comment.new
    @block_users = BlockUser.find_block_user(current_user.id).map(&:user_id)
  end
end
