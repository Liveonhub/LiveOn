class FriendsController < ApplicationController
  before_action :find_friend_requests, only: [:index, :send_request_to_friends, :my_friends]

  def index
    @total_record = params[:total_record].nil? ? Friend::FRIENDS_PER_PAGE : params[:total_record]
    @friends = @friends.first(@total_record.to_i)
    @pending_friend_requests = @pending_friend_requests.first(@total_record.to_i)
    @sent_friend_requests = @sent_friend_requests.first(@total_record.to_i)
    respond_to do |format|
      format.html {}
      format.js  {}
    end 
  end 

  def send_request_to_friends
    @pending_requests = current_user.pending_and_sent_friend_requests
    @search_friends = User.search_friends(params[:search], current_user.id)
  end

  def create
    @friend = current_user.friendships.create(status: params[:status],  friend_id: params[:friend_id])
    if @friend.persisted?
      @success_message = "Request sent successfully"     
    else
      @error_message = "Request not sent successfully"     
    end
    respond_to do |format|
      format.js  {}
    end
  end

  def update
    friend = Friend.find_friendship(current_user.id, params[:id]).first
    if friend.present? && friend.update_attribute(:status, "approved")
      @success_message = "Request accepted successfully"     
    else
      @error_message = "Request not accepted successfully"  
    end
    respond_to do |format|
      format.js  {}
    end 
  end

  def destroy
    friend = Friend.find_friendship(current_user.id, params[:id]).first
    if friend.present? && friend.destroy
      @success_message = "Request deleted successfully"     
    else
      @error_message = "Request not deleted successfully"     
    end
    respond_to do |format|
      format.js  {}
    end 
  end

  def my_friends
    @current_user_pending_requests = sorting_by_first_name(current_user.pending_friend_requests) 
    @current_user_friends = sorting_by_first_name(current_user.my_friends)
    @current_user_sent_requests = sorting_by_first_name(current_user.sent_friend_requests) 
    @mutual_friends = @friends && @current_user_friends - [@user]
  end

  private
  def find_friend_requests
    @user = params[:user_id].present? ? User.find_by_id(params[:user_id]) : current_user
    @friends = sorting_by_first_name(@user.my_friends) - [current_user] 
    @pending_friend_requests = sorting_by_first_name(@user.pending_friend_requests)
    @sent_friend_requests = sorting_by_first_name(@user.sent_friend_requests)
  end

  def sorting_by_first_name(params)
    params.uniq.sort_by { |obj| obj.first_name.downcase }
  end
end


