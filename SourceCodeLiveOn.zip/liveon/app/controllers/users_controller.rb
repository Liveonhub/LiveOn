class UsersController < ApplicationController
  before_action :authenticate_user!, except: %i(index)
  before_action :set_user, except: %i(index new search_friends)
  before_action :set_attachment_record, only: %i(delete_attachment update_attachment edit_attachment)

  def index
    redirect_to new_user_registration_path
  end

  def new
    
  end

  def edit
  end

  def update
    if @user.update_attributes(user_params)
      user_photos_and_videos
      if params[:commit] == "Save"
        redirect_to posts_path
      else
        flash[:success] = "Profile updated successfully"
        redirect_to edit_user_path(@user)
      end
    elsif params[:commit] == "Save"
      render "new"
    else
      render "edit"
    end
  end

  def search_friends
    @search_friends =  User.search_friends(params[:search], current_user.id)
    respond_to do |format|
      format.js  {}
    end  
  end

  def show

  end

  def upload_photos_and_videos
    if @user.update_attributes(user_params)
      user_photos_and_videos
      flash[:success] = "File uploaded successfully"
      case params[:current_page]
      when "photos" 
        redirect_to photos_user_path(@user.id) 
      when "videos" 
        redirect_to videos_user_path(@user.id)  
      when "show"
        redirect_to user_path(@user.id)
      when "user_posts"
        redirect_to user_posts_path(user_id: @user.id)
      else
        redirect_to friends_path(user_id: @user.id)
      end
    end
  end

  def delete_attachment
    id = params[:video_id].present? ? params[:video_id] : params[:photo_id]
    attachment = ActiveStorage::Attachment.where(id: id).first
    if attachment.destroy
      @attachment_record.destroy
      flash[:success] = "File deleted successfully"
      if params[:photo_id] 
        redirect_to photos_user_path(params[:id]) 
      else 
        redirect_to videos_user_path(params[:id])  
      end 
    end
  end

  def edit_attachment
    respond_to do |format|
      format.html  {}
      format.js  {}
    end  
  end

  def update_attachment
    @attachment_record.attachment_type = params[:attachment_record][:attachment_type]
    if @attachment_record.save
      respond_to do |format|
        format.html  {}
        format.js  {}
      end
    end
  end

  def photos
    @photo_attachments = photos_videos
  end

  def videos
    @video_attachments = photos_videos
  end

  def photos_videos
    @user.attachment_records.where("attachment_type not in (?)", ["cover_photo", "profile_photo"]).order(:updated_at => 'desc')
  end

  private
  def user_params
    params.require(:user).permit(:first_name, :last_name, :user_name, :date_of_birth, :gender, :mobile_number, :profession, :email, images: [])
  end  

  def set_user
    if params[:id]
      @user = User.find_by_id(params[:id])
    else
      @user = current_user
    end
  end

  def set_attachment_record
    @attachment_record = AttachmentRecord.find_by_id(params[:attachment_id])
  end

  def user_photos_and_videos
    @attachment_record = nil
    if params[:image_type] == "cover_photo" || params[:image_type] == "profile_photo"
      @attachment_record = AttachmentRecord.find_by_user_id_and_attachment_type(@user.id, params[:image_type])
    end
    params[:user][:images] = [] if params[:user][:images].nil?
    new_attachments = ActiveStorage::Attachment.where(record_type: "User", record_id: @user.id).last(params[:user][:images].count).map(&:id) 
    if @attachment_record
      @attachment_record.attachment_id = new_attachments[0]
      @attachment_record.save
    else
      new_attachments.each do |attachment|
        AttachmentRecord.create(attachment_id: attachment, user_id: @user.id, attachment_type: params[:image_type])
      end
    end   
  end
end
