class MyMailer < ApplicationMailer
  
  def reset_password_link_to_nominee(token, nominee, post_record)
    @death_user = post_record.death_person
    @nominee  = nominee
    @post_user = post_record
    @token = token
    mail(to: @nominee.email, subject: 'Reset password instructions')
  end
end
