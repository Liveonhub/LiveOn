
// banner script

$(document).ready(function(){
	
	$('.homepageBn').owlCarousel({
	    items:1,
	    margin:0,
	    autoHeight:true,
	    nav:true,
	    dots: false,
	    loop:true,
	    navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
	    responsiveClass:true,
	    responsive:{
	        0:{
	            items:1,
	            nav:true
	        },
	        600:{
	            items:1,
	            nav:true
	        },
	        1000:{
	            items:1,
	            nav:true
	        }
	    }
	    
	});


	$('.clientSlider').owlCarousel({
	    items:5,
	    margin:70,
	    autoHeight:true,
	    nav:false,
	    dots: true,
	    loop:true,
	    navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
	    responsiveClass:true,
	    responsive:{
	        0:{
	            items:1,
	            margin:0
	        },
	        600:{
	            items:1,
	            margin:0
	        },
	        1000:{
	            items:1,
				margin:0
	        }
	    }
	});

	$('.featuredSlider').owlCarousel({
	    items:5,
	    margin:30,
	    autoHeight:true,
	    dots: false,
		loop:true,
		nav: true,
	    navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
	    responsiveClass:true,
	    responsive:{
	        0:{
	            items:1,
	            margin:15
			},
			540:{
	            items:2,
	            margin:15
	        },
	        768:{
	            items:2,
	            margin:15
	        },
	        992:{
				items:3,
				nav:true
	        }
	    }
	});

	$('.partnerSlider').owlCarousel({
	    items:3,
	    autoHeight:true,
	    nav:true,
	    dots: false,
	    loop:true,
	    navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
	    responsiveClass:true,
	    responsive:{
	        0:{
	            items:1,
	            nav:true
	        },
	        480:{
	            items:3,
	            nav:true
	        },
			768:{
	            items:4,
	            nav:true
	        },
	        992:{
	            items:6,
				nav:true,
	        }
	    }
	});


	$('.gdVideoSlider').owlCarousel({
	    items:1,
	    autoHeight:true,
	    nav:false,
	    dots: true,
	    loop:true,
	    responsiveClass:true,
	    responsive:{
	        0:{
	            items:1
	        },
	        480:{
	            items:1
	        },
			768:{
	            items:1
	        },
	        992:{
	            items:1
	        }
	    }
	});

	

	$('#leftDivContentWrapperBlogDetail').stickySidebar({
		topSpacing: navBar,
		bottomSpacing: 0
	});


	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
	acc[i].addEventListener("click", function() {
		this.classList.toggle("active");
		var panel = this.nextElementSibling;
		if (panel.style.maxHeight){
		panel.style.maxHeight = null;
		} else {
		panel.style.maxHeight = panel.scrollHeight + "px";
		} 
	});
	}



	// menu js

	// Menu Script

	// click toggle to toggleClass for navbar
	$('.toggleMenu').click(function(event) {
	  $('body').toggleClass('open');
	});

	// click overlay to remove body class
	$('.overlay').click(function(event) {
	  $('body').removeClass('open');
	  $('.parent').removeClass('thirdLabel secondLabel fourthLabelabel');
	});

	// add li as a first child
	//$('.sub-menu').prepend("<li class='backTo'><a href='javascript:void(0)'><i class='fa fa-angle-left'></i>Back</a></li>");

	// firstlabel open
	$('.nav > li.parent > a').on('click', function(e) {
	  $(this).parent('.nav > li').toggleClass('secondLabel');
	});

	// slideleft
	// $('body').on('click', '.secondLabel .subMenuCount', function(e) {
	//   $(this).parent('.secondLabel').parents('.secondLabel').removeClass('secondLabel')
	// });

	// secondlabel open
	$('.secondLabel > li.parent > a').on('click', function(e) {
	  $(this).parent('.secondLabel > li').toggleClass('thirdLabel');
	});

	// slideleft
	// $('body').on('click', '.thirdLabel .backTo', function(e) {
	//   $(this).parent('.thirdLabel').parents('.thirdLabel').removeClass('thirdLabel')
	// });

	// thirdlabel open
	$('.thirdLabel > li.parent > a').click(function() {
	  $(this).parent('.thirdLabel > li').addClass('fourthLabel');
	});

	// slideleft
	// $('body').on('click', '.fourthLabel .backTo', function(e) {
	//   $(this).parent('.fourthLabel').parents('.fourthLabel').removeClass('fourthLabel')
	// });



	// fixed scroll
	var navBar = $('.navbar ').outerHeight();

	$('#leftDivContentWrapper').stickySidebar({
		topSpacing: navBar,
		bottomSpacing: 0
	});

});

