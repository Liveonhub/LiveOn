// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, or any plugin's
// vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file. JavaScript code in this file should be added after the last require_* statement.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
//












$( document ).ready(function() {
  $('#log-in').click(function (){ 
    setTimeout(function(){ 
      $('.ajax-error').text('');
    }, 9000);
  })

  $('#forgot-password').click(function (){ 
    setTimeout(function(){ 
      $('#password-error').text('');
    }, 9000);
  })

  $('.date-pic').click(function (){ 
    $( "#datepicker-13" ).datepicker({
      dateFormat: "dd/mm/yy",
      changeYear: true,
      yearRange: '1980:2025' 
    });
    $( "#datepicker-13" ).datepicker("show"); 
  })
  

  window.onscroll = function() {myFunction()};

  var header = document.getElementById("header");
  var sticky = header.offsetTop;

  function myFunction() {
    if (window.pageYOffset > sticky) {
      header.classList.add("sticky");
    } else {
      header.classList.remove("sticky");
    }
  }

  $('.input-file-value').change(function(){
    var f = this.files[0];  
    var name = f.name;
    $(this).parents('.fileupload-block').find('.file-value').text(name);
  });
  
  $('#user_term_and_condition').after('<span class="checkmark1"></span>');

  function displayThumbnail(input) {
    for( var i = 0; i<input.files.length; i++){
      if (input.files && input.files[i]) {
        var reader = new FileReader();
        reader.onload = function (e) {  
          var source_path = e.target.result.split('/')[0]
          if (source_path === "data:video") {
            var $newImageThumbnail = makeElement('video',{ class: "video-frame",src: e.target.result});
          }
          else{
            var $newImageThumbnail = makeElement('img',{ class: "image-frame",src: e.target.result});
          }
          console.log($newImageThumbnail)
          $('#uploader-wrapper').append($newImageThumbnail);
        };
        reader.readAsDataURL(input.files[i]);
      }
    }
  }

  function makeElement(element, options) {
    var $elem = document.createElement(element);
    $.each(options, function (key, value) {
      $elem.setAttribute(key, value);
    });
    return $elem;
  }

  $("#post_images").change(function(){
    displayThumbnail(this);
  });

  $(function() {
    $(".search-user").autocomplete({     
      source : function(request, response) {
        var search_text = request.term
        $.ajax({
            url : "/users/search_users",
            type : "GET",
            data : { search: search_text }
        });
      }
    });
  });

  $('.fa.fa-search').on('click', function() {
    $("#show-search-users").hide();
  });



});

function reply_click(dynamic_id) {
  var id = "#"+dynamic_id+" .hideshow-replyform"
  $(id).show();
}

