// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, or any plugin's
// vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file. JavaScript code in this file should be added after the last require_* statement.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
//
//= require jquery3
//= require rails-ujs
//= require bootstrap.min
//= require_tree .
//= require activestorage
//= require custom
//= require customSelect
//= require scrollbackground
//= require jquery.sticky-sidebar
//= require turbolinks
//= require owl.carousel.min


$( document ).on('turbolinks:load', function() {

  // login & signup errors 

  $('#log-in').click(function (){ 
    setTimeout(function(){ 
      $('.ajax-error').text('');
    }, 9000);
  })

  $('#forgot-password').click(function (){ 
    setTimeout(function(){ 
      $('#password-error').text('');
    }, 9000);
  })

  $('#user_images').change(function(){
    var f = this.files[0];  
    var name = f.name;
    $(this).parents('.fileupload-block').find('.file-value').text(name);
  });
  
  $('#user_term_and_condition').after('<span class="checkmark"></span>');
  $('#user_gender_female').after('<span class="checkmark"></span>');
  $('#user_gender_male').after('<span class="checkmark"></span>');

  $('.date-pic').click(function (){ 
    $( "#datepicker-13" ).datepicker({
      dateFormat: "dd/mm/yy",
      changeYear: true,
      yearRange: '1950:2025', 
      maxDate: new Date()
    });
    $( "#datepicker-13" ).datepicker("show"); 
  })  
  
  window.onscroll = function() {myFunction()};

  var header = document.getElementById("header");
  var sticky = header.offsetTop;

  function myFunction() {
    if (window.pageYOffset > sticky) {
      header.classList.add("sticky");
    } else {
      header.classList.remove("sticky");
    }
  }

  // search friends
  $(function() {
    $(".search-user").autocomplete({     
      source : function(request, response) {
        var search_text = request.term
        $.ajax({
            url : "/users/search_friends",
            type : "GET",
            data : { search: search_text }
        });
      }
    });
  });

  $('.fa.fa-search').on('click', function() {
    $("#show-search-users").hide();
  });

  $('.icon-add').on('click', function() {
    $("#new_nominee_1").toggle();
    $('.icon-add').toggle()
  });

  // preview images videos audio of post

  function displayThumbnail(input) {
    for(i = 0; i<input.files.length; i++){

      if (input.files && input.files[i]) {
        var reader = new FileReader();
        reader.onload = function (e) {  
          var source_path = e.target.result.split('/')[0]
          if (source_path === "data:video") {
            var $newImageThumbnail = makeElement('video',{ class: "video-frame",src: e.target.result});
          }
          else if (source_path === "data:audio"){
            var $newImageThumbnail = makeElement('img',{ class: "image-frame",src: '/assets/audio.png'});
          }
          else{
            var $newImageThumbnail = makeElement('img',{ class: "image-frame",src: e.target.result});
          }
          // $('#uploader-wrapper').append("<a class='close-image'><i class='fa fa-times' aria-hidden='true'></i></a>")
          $('#uploader-wrapper').append($newImageThumbnail);
          $("#post_body").attr("required", false);

        };        
        reader.readAsDataURL(input.files[i]);
      }
    }
  }

  function makeElement(element, options) {
    var $elem = document.createElement(element);
    $.each(options, function (key, value) {
      $elem.setAttribute(key, value);
    });
    return $elem;
  }

  $("#post_images").change(function(){
    displayThumbnail(this);
  });

  $(".post-images").click(function (argument) {
    $('#uploader-wrapper').html('')
    $("#post_images").click()
  })

  // post for death friend
  $('#post_category').on('change', function() {
    if ($("#post_category").val() === "2")
    {
      $('#post_category_error').html(" ");
      $(".find-dead-person").show();
      $("#datepicker-13").attr("required", true);
    }
    else 
    {
      $('#post_category_error').html(" ");
      $(".find-dead-person").hide();
    }    
  });

  $("#submit-post").click(function () {
    if ($("#post_category").val() === "1")
    {
      $("#datepicker-13").attr("required", false);
    }
    if ($("#post_category").val() === "2" && $("#post_death_person_id").val() == "")
    {
      $('#post_category_error').html(`Search body can't blank`);
      return false;
    }
  });

  $("#post_death_person_id").on('keyup', function(){
    var search = $(this).val();
    $.ajax({
      type: "GET",
      url: "/posts/death_friend_post",
      data: {search: search},
      success: function(data){
        $(function() {
          var users = data
          $("#post_death_person_id").autocomplete({
            source: users,
            minLength: 1,
            select: function(event, ui) {
              //$("#friend_id").val(ui.item.id)  
              // var url = ui.item.id;
              // if(url != '') {
              //   location.href = '...' + url;
              // }
              
            },
            html: true, 
            open: function(event, ui) {
              $(".ui-autocomplete").css("z-index", 1000);

            }
          })
            .autocomplete( "instance" )._renderItem = function( ul, item ) {
            return $( "<li><div><img src='"+item.img+"'><span>"+item.value+"</span></div></li>" ).appendTo( ul );
          };
        });
      }  
    })  
  })

  $('body').on('click', 'a.close-image', function() {
    $(this).next().remove();
    $(this).remove();
  });

  // upload user cover and profile photo

  function readcoverURL(input) {
    var photo_format = $("#cover-photo")[0]["files"][0]["name"].split(".")[1]
    if (input.files.length >= 2 || !['jpeg', 'gif', 'jpg', 'png'].includes(photo_format) ){
      $(".photo-error").html("Select only a photo <br><br>")
      $("#show-cover-photo").removeAttr('src')
      $("#upload-cover-button").hide()
      return false;
    }
    $(".photo-error").html(" ")
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
        $('#show-cover-photo').attr('src', e.target.result);
        $('#show-cover-photo').after("<div><br></div>")
      }
      reader.readAsDataURL(input.files[0]);
      $("#upload-cover-button").show()
    }
  }

  $("#cover-photo").change(function(){
    $('#show-cover-photo').next().remove();
    readcoverURL(this);
  });


  function readprofileURL(input) {
    var photo_format = $("#profile-photo")[0]["files"][0]["name"].split(".")[1]
    if (input.files.length >= 2 || !['jpeg', 'gif', 'jpg', 'png'].includes(photo_format) ) {
      $(".photo-error").html("Select only a photo <br><br>")
      $("#show-profile-photo").removeAttr('src')
      $("#upload-profile-button").hide()
      return false;
    }

    $(".photo-error").html(" ")

    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
        $('#show-profile-photo').attr('src', e.target.result);
        $('#show-profile-photo').after("<div><br></div>")
      }
      reader.readAsDataURL(input.files[0]);
    }
    $("#upload-profile-button").show()
  }

  $("#profile-photo").change(function(){
    $('#show-profile-photo').next().remove();
    readprofileURL(this);
  });

  $(".close").click(function (argument) {
    $(".photo-error").html("");
    $("#profile-photo").val('')
    $("#cover-photo").val('')
  })

  // upload multiple photos by user

  $("#user_multiple_images").change(function(){
    $('#uploader-wrapper').html('')
    displayMultiplePhotos(this);
  });

  function displayMultiplePhotos(input) {
    for( var i = 0; i<input.files.length; i++){
      if (input.files && input.files[i]) {
        var reader = new FileReader();
        reader.onload = function (e) {  
          var source_path = e.target.result.split('/')[0]
          if (source_path === "data:image"){ 
            var $newImageThumbnail = makeElement('img',{ class: "image-frame",src: e.target.result});
          }
          if (source_path === "data:video"){ 
            var $newImageThumbnail = makeElement('video',{ class: "video-frame",src: e.target.result});
          }
          $('#uploader-wrapper').append($newImageThumbnail);
        }
        reader.readAsDataURL(input.files[i]);
      }
    }
    if (input.files.length > 0) {
      $("#upload-photo-button").show()
      $(".photo_type").show()
    }
    else{
      $("#upload-photo-button").hide()
      $(".photo_type").hide() 
    }
  }

  function makeElement(element, options) {
    var $elem = document.createElement(element);
    $.each(options, function (key, value) {
      $elem.setAttribute(key, value);
    });
    return $elem;
  }

  $("#cancel-report-profile").click(function (argument) {
    $(".report_user_form").toggle();
    $(".report-block-user").toggle();
  })

  $("#report-user-button").click(function (argument) {
    if($("#report_profile_title").val() != "")
    {
      alert("Are you confirm?")
    }
  })
});

// show reply box 
function reply_function(comment_id) {
  var id = "#"+comment_id+" .hideshow-replyform"
  id = id.replace("reply_link", "reply_form");
  $(id).toggle();
}

// show comments  

function show_comments_function(post_id) {
  var post_id = "#"+post_id+' .hide-show-comment';
  post_id = post_id.replace("show", "post");
  $(post_id).toggle();
}

function cancel_edit_image(attachment_id, params) {
  var id = ("#edit-photo-").concat(attachment_id).concat(" .heading-photo")
  $(id).html(params)
}

