class AttachmentRecord < ApplicationRecord
  belongs_to :attachment, :class_name => "ActiveStorage::Attachment"
  belongs_to :user
end
