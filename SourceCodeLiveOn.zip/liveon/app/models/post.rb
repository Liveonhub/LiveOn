class Post < ApplicationRecord
  belongs_to :user
  belongs_to :death_person, :class_name => "User", optional: true
  has_many_attached :images
  has_many :comments, dependent: :destroy
  has_many :likes, as: :likeable, dependent: :destroy
  enum post_types: [:Public, :Me, :Friends]
  validates :post_type, presence: true
  after_create :send_email_to_nominees

  scope :post_by_type, ->(user){
    where("post_type = ? AND user_id = ? or post_type = ? or post_type = ? AND user_id IN (?)" , 'Me', user.id, 'Public', 'Friends',  user.my_friends.map(&:id).push(user.id)).order(:updated_at => 'desc')
  }

  def find_like_on_post(user_id)
    Like.find_by_likeable_type_and_likeable_id_and_user_id("Post", self.id, user_id)
  end

  private
  def send_email_to_nominees
    if death_person_id.present?
      raw, enc = Devise.token_generator.generate(death_person.class, :reset_password_token)
      death_person.reset_password_token   = enc
      death_person.reset_password_sent_at = Time.now.utc
      death_person.is_death = true
      death_person.save(validate: false)
      death_person.nominees.each do |nominee|
        MyMailer.reset_password_link_to_nominee(raw, nominee, self).deliver_now
      end
    end
  end
end
