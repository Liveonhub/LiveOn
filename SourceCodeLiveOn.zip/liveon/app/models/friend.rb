class Friend < ApplicationRecord
  belongs_to :user
  belongs_to :friend, :class_name => "User"
  validates :status, presence: true

  scope :pending, ->{where(status: 'pending')}
  scope :approved, ->{where(status: 'approved')}

  scope :by_user, ->(user_id){
    where("user_id = ? or friend_id = ?", user_id, user_id)
  }

  scope :find_friendship, ->(user_id, friend_id){
    where("(user_id = ? && friend_id = ?) OR (user_id = ? && friend_id = ?)", user_id, friend_id, friend_id, user_id)
  }

  FRIENDS_PER_PAGE = 8
end
