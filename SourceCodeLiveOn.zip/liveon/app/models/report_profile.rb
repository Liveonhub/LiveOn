class ReportProfile < ApplicationRecord
  belongs_to :report_profile, class_name: "User"
  belongs_to :user
  validates :title, presence: true
end
