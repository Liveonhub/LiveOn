class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :lockable, :timeoutable, :trackable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable, :confirmable, :omniauthable, omniauth_providers: %i[facebook twitter]
  has_many_attached :images
  has_many :attachment_records, dependent: :destroy
  has_many :posts, dependent: :destroy
  has_many :comments, dependent: :destroy
  has_many :nominees, dependent: :destroy
  has_many :likes, as: :likeable, dependent: :destroy
  has_many :friendships, class_name: 'Friend', foreign_key: 'user_id', dependent: :destroy
  has_many :friends, :through => :friendships, dependent: :destroy
  has_many :inverse_friendships, :class_name => "Friend",  :foreign_key => "friend_id", dependent: :destroy
  has_many :inverse_friends, :through => :inverse_friendships, :source => :user
  has_many :report_profiles, dependent: :destroy
  has_many :block_users, dependent: :destroy
  validates :mobile_number,:presence => true,
                 :numericality => true,
                 :length => { :minimum => 10, :maximum => 10 }
  validates :first_name, :last_name, :term_and_condition, :gender, :date_of_birth, presence: true
  validates_uniqueness_of :mobile_number
  before_validation :username_and_searchname

  def username_and_searchname
    if user_name.present? 
      self.errors[:base] << "Space not allow with username" unless user_name.match(/\s/) == nil
    end
    self.search_name = "#{first_name}#{last_name}".delete(' ')
  end

  def self.from_facebook_omniauth(auth)
    auth_user = User.find_user_from_socail_network(auth)
    if auth_user.nil?
      auth_user = User.new
      auth_user.email = auth.info.email if auth.info.email.present?
      auth_user.provider = auth.provider
      auth_user.uid = auth.uid
      auth_user.password = Devise.friendly_token[0,20]
      auth_user.user_name = auth.info.name if auth.info.name.present?
      auth_user.gender = auth[:extra][:raw_info][:gender].camelize
      auth_user.date_of_birth = auth[:extra][:raw_info][:birthday]
      auth_user.term_and_condition = true
      auth_user.first_name = auth.info.first_name
      auth_user.last_name = auth.info.last_name
      auth_user.save(validate: false)
    end
    auth_user
  end

  def self.from_twitter_omniauth(auth)
    auth_user = User.find_user_from_socail_network(auth)
    if auth_user.nil?
      auth_user = User.new
      auth_user.email = auth.info.email if auth.info.email.present?
      auth_user.provider = auth.provider
      auth_user.uid = auth.uid
      auth_user.password = Devise.friendly_token[0,20]
      auth_user.user_name = auth.info.name   
      auth_user.term_and_condition = true
      auth_user.save(validate: false)
    end
    auth_user
  end

  def self.from_instagram_omniauth(auth)
    where(provider: auth.provider, uid: auth.uid).first_or_create do |user|
      user.email = auth.info.email
      user.password = Devise.friendly_token[0,20]
      user.user_name = auth.info.nickname   
      user.term_and_condition = true
      user.first_name = auth.info.name
      user.last_name = auth.info.nickname.split(auth.info.name.downcase).last if auth.info.name.present?
    end
  end

  def self.find_user_from_socail_network(auth)
    user_exist = nil
    if auth.info.email.present?
      user_exist = where("uid = ? and provider =? or email =?", auth.uid, auth.provider, auth.info.email).first
    elsif User.exists?(provider: auth.provider, uid: auth.uid)
      user_exist = where(provider: auth.provider, uid: auth.uid).first
    end
    if user_exist.present?
      user_exist.uid = auth.uid
      user_exist.provider = auth.provider
      user_exist.save(validate: false)
    end
    user_exist
  end

  def self.new_with_session(params, session)
    super.tap do |user|
      if data = session["devise.facebook_data"] && session["devise.facebook_data"]["extra"]["raw_info"]
        user.email = data["email"] if user.email.blank?
      end
    end
  end   

  def full_name
    "#{first_name} #{last_name}"
  end    

  def my_friends
    Friend.by_user(self.id).approved.map{ |frnd| [frnd.user, frnd.friend] }.flatten.uniq - [self]
  end

  def pending_and_sent_friend_requests
    Friend.by_user(self.id).pending.map{ |frnd| [frnd.user, frnd.friend] }.flatten.uniq - [self]
  end

  def pending_friend_requests
    Friend.by_user(self.id).pending.where(friend_id: id).map(&:user)
  end

  def sent_friend_requests
    Friend.by_user(self.id).pending.where(user_id: id).map(&:friend)
  end

  def self.search_friends(search_by, user_id)
    search_by = search_by.delete(' ')
    block_users = BlockUser.find_block_user(user_id).map(&:user_id).push(user_id).uniq
    where('search_name LIKE ? OR email LIKE ? OR mobile_number LIKE ?', "%#{search_by}%", "%#{search_by}%", "%#{search_by}%").where("id NOT IN (?)", block_users)
  end
end
