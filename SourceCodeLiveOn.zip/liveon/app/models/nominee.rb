class Nominee < ApplicationRecord
  belongs_to :user
  validates :mobile_number, :presence => true,
                 :numericality => true,
                 :length => { :minimum => 10, :maximum => 10 }
  validates_format_of :email, :with => /\A[^@]+@([^@\.]+\.)+[^@\.]+\z/
  validates_uniqueness_of :mobile_number, :email           
end
