class Comment < ApplicationRecord
  belongs_to :user
  belongs_to :post
  has_many :replies, class_name: "Comment", foreign_key: "parent_id", dependent: :destroy
  belongs_to :parent, class_name: "Comment", optional: true
  has_many :likes, as: :likeable, dependent: :destroy
  validates :body, presence: true
  
  def find_like_on_comment(user_id)
    Like.find_by_likeable_type_and_likeable_id_and_user_id("Comment", self.id, user_id)
  end

end
