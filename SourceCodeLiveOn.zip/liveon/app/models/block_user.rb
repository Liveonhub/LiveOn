class BlockUser < ApplicationRecord
  belongs_to :block_user, class_name: "User"
  belongs_to :user

  after_create :unfriend_block_user
  
  scope :find_block_user, ->(user_id){
    where("block_user_id = ?", user_id)
  }
  private

  def unfriend_block_user
    friendship = Friend.find_friendship(user_id, block_user_id).first
    if friendship.present?
      friendship.destroy
    end
  end
end
