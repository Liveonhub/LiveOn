module UsersHelper
  def get_image_path(user, params, options = {})
    attachment_record = user.attachment_records.find_by_attachment_type(params)
    attachment = ActiveStorage::Attachment.where(id: attachment_record.try(:attachment_id), record_type: "User", record_id: user.id).first
    if attachment.present? && options.present?
      Rails.application.routes.url_helpers.rails_blob_path(user.images.find_by_id(attachment.id), only_path: true)
    elsif params == "cover_photo" && attachment_record.try(:attachment_type) == params
      image_url (rails_blob_path(user.images.find_by_id(attachment.id)))
    elsif params == "cover_photo" 
      image_path('cover_dp.jpeg')
    elsif params == "profile_photo" && attachment_record.try(:attachment_type) == params
      image_url (rails_blob_path(user.images.find_by_id(attachment.id)))
    else
      "/assets/icon_17.png"
    end
  end

  def user_date_of_birth_format(user)
    user.date_of_birth.strftime('%d %B %Y')
  end
end
