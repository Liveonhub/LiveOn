module PostsHelper
  def datetime_format(object)
    object.created_at.localtime.strftime('%d %B %Y %H:%M %p')
  end
end
