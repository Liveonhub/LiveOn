OmniAuth.config.logger = Rails.logger

Rails.application.config.middleware.use OmniAuth::Builder do

  provider :facebook, Rails.application.secrets.facebook_app_key, Rails.application.secrets.facebook_app_secret, scope: 'email, user_birthday, user_gender', info_fields: 'email, name, first_name, last_name, gender, birthday, location, picture'
  
  provider :twitter, Rails.application.secrets.twitter_app_key, Rails.application.secrets.twitter_app_secret,     {
      :secure_image_url => 'true',
      :image_size => 'original',
    }
  provider :instagram, Rails.application.secrets.instagram_app_key, Rails.application.secrets.instagram_app_secret

end   