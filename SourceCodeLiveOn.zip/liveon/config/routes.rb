Rails.application.routes.draw do
  devise_for :users, controllers: {sessions: 'users/sessions', registrations: "users/registrations", omniauth_callbacks: 'users/omniauth_callbacks', passwords: 'users/passwords'}
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  
  # this routes for social networking sites
  match 'auth/:provider/callback', to: 'sessions#create', via: [:get, :post]
  match 'auth/failure', to: redirect('/'), via: [:get, :post]
  match 'signout', to: 'sessions#destroy', as: 'signout', via: [:get, :post]

  #root routing for authenticated & unauthenticated user
  devise_scope :user do
    authenticated :user do
      root 'posts#index', as: :authenticated_root
    end
    unauthenticated do
      root 'users/registrations#new', as: :unauthenticated_root
    end
  end

  resources :nominees, :friends do 
    collection do
      get 'send_request_to_friends'
      get 'my_friends'
    end
  end
  resources :users do
    collection do
      get 'search_friends'
    end
    member do 
      put 'upload_photos_and_videos'
      get 'photos'
      get 'videos'
      delete 'delete_attachment'
      put 'update_attachment'
      get 'edit_attachment'
    end
    resources :report_profiles do 
      delete 'unblock'
    end
  end
  
  resources :posts do 
    collection do
      get 'death_friend_post'
    end
    resources :comments, :likes
  end
  resources :comments do 
    resources :likes, :replies 
  end
  resources :replies do
    resources :likes
  end 
  get 'user_posts', :to => 'posts#user_posts'
end
